=======
SearXNG
=======

SearXNG development has been started in the middle of 2021 as a fork of the
searx project.  Since it beginning its a rolling release pulled from SearXNG's
master branch:

- The CHANGELOG_ is replaced by the commit history of the master branch.
- Since merged PR-229_, the version number is based on the git commit

.. _CHANGELOG: https://github.com/searxng/searxng/commits/master
.. _PR-229: https://github.com/searxng/searxng/pull/229

