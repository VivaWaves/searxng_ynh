.. _archlinux engine:

==========
Arch Linux
==========

.. automodule:: searx.engines.archlinux
  :members:

