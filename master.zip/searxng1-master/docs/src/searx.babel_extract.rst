.. _searx.babel_extract:

===============================
Custom message extractor (i18n)
===============================

.. automodule:: searx.babel_extract
  :members:
