.. automodule:: searx.engines.annas_archive
   :members:
