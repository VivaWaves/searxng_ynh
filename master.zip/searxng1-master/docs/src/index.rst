===========
Source-Code
===========

This is a partial documentation of our source code.  We are not aiming to document
every item from the source code, but we will add documentation when requested.


.. toctree::
   :maxdepth: 2
   :caption: Contents
   :glob:

   searx.*
