.. _tor check plugin:

================
Tor check plugin
================

.. automodule:: searx.plugins.tor_check
  :members:

