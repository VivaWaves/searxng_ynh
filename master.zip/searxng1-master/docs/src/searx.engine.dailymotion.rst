.. _dailymotion engine:

===========
Dailymotion
===========

.. automodule:: searx.engines.dailymotion
  :members:
