===========================
Administrator documentation
===========================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   installation
   installation-docker
   installation-scripts
   installation-searxng
   installation-uwsgi
   installation-nginx
   installation-apache
   update-searxng
   answer-captcha
   engines/index
   api
   architecture
   plugins
   buildhosts
